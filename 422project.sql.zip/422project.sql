/* Failed to load query with error:
The file “422project.sql” couldn’t be opened using text encoding Unicode (UTF-8).
*/